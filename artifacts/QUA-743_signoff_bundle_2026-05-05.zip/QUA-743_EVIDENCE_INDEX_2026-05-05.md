## QUA-743 Evidence Index (2026-05-05)

### Core EA / Build Artifacts

- `QM5_SRC04_S03_lien_fade_double_zeros.mq5`
- `QM5_SRC04_S03_lien_fade_double_zeros.ex5`
- `P2_baseline_matrix_manifest.json`
- `QM-00011_CTO_REVIEW_PASS_2026-05-05.md`

### Drift / Promotion / Block-State Notes

- `QUA-743_CONTINUATION_DRIFT_NOTE_2026-05-05.md`
- `QUA-743_P2_PROMOTION_READY_2026-05-05.md`
- `QUA-743_BLOCKED_PRECONDITION_2026-05-05.md`
- `QUA-743_P2_DISPATCH_HANDOFF_2026-05-05.md`

### Execution Probes & Infra Fix Trail

- `QUA-743_P2_EXECUTION_PROBE_2026-05-05.md`
- `QUA-743_P2_CLASSIFICATION_FIX_2026-05-05.md`
- `QUA-743_P2_RETRY_PROBE_2026-05-05.md`
- `QUA-743_EXECUTION_UNBLOCKED_MINTRADES_2026-05-05.md`

### Zero-Trades Recovery Chain

- `ZT_RootCause_QM5_SRC04_S03_20260505.md`
- `QUA-743_ZT_COHORT_EVIDENCE_20260505.csv`
- `QUA-743_ZT_RECOVERY_SIGNOFF_PACKET_2026-05-05.md`
- `QUA-743_V2_BUILD_READY_CHANGE_SPEC_2026-05-05.md`
- `QUA-743_ZT_SIGNOFF_DECISION_FORM_2026-05-05.md`

### Pipeline Output Anchors

- `D:/QM/reports/pipeline/QM5_SRC04_S03/P2/report.csv`
- `D:/QM/reports/pipeline/QM5_SRC04_S03/P2/p2_QM5_SRC04_S03_result.json`
- `D:/QM/reports/pipeline/QM5_SRC04_S03/P2/QM5_1009/` (per-run smoke summaries and raw logs)

### Current Operational Position

- EA review and dispatch plumbing are complete for v1.
- Cohort ZT threshold is met (`5/5`).
- Awaiting R-and-D signoff + CEO dispatch for v2 build execution.
