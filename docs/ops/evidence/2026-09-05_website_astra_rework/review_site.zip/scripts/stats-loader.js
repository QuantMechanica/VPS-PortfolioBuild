/**
 * stats-loader.js
 * Dynamically loads stats.json and populates data-stat elements across the site.
 * Ensures numbers are always up-to-date with the latest QuantMechanica Factory results.
 */
(function() {
  const statsPath = '/public-data/stats.json';
  const fallbackStatsPath = '/data/stats.json';

  function formatNumber(num) {
    if (typeof num !== 'number') return num;
    return num.toLocaleString('en-US');
  }

  function updateElements(stats) {
    if (!stats) return;

    // Update all elements with data-stat attributes
    document.querySelectorAll('[data-stat]').forEach(el => {
      const key = el.getAttribute('data-stat');
      if (stats[key] !== undefined) {
        const val = stats[key];
        const formatted = (typeof val === 'number') ? formatNumber(val) : val;
        
        // If element has data-target (counter animation), update target value
        if (el.hasAttribute('data-target')) {
          el.setAttribute('data-target', val);
        } else {
          el.textContent = formatted;
        }
      }
    });

    // Update dynamic text templates
    document.querySelectorAll('[data-stat-template]').forEach(el => {
      let text = el.getAttribute('data-stat-template');
      for (const [k, v] of Object.entries(stats)) {
        const formatted = (typeof v === 'number') ? formatNumber(v) : v;
        text = text.replace(new RegExp(`{${k}}`, 'g'), formatted);
      }
      el.textContent = text;
    });
  }

  // Fill [data-stat-date] elements with the stats.json generated_at,
  // formatted YYYY-MM-DD. If generated_at is missing/unparseable the
  // element keeps its static fallback text.
  function formatDate(generatedAt) {
    if (!generatedAt) return null;
    var s = String(generatedAt);
    var m = s.match(/^(\d{4})-(\d{2})-(\d{2})/);   // ISO date prefix, TZ-safe
    if (m) return m[1] + '-' + m[2] + '-' + m[3];
    var d = new Date(s);
    if (!isNaN(d.getTime())) {
      return d.getFullYear() + '-' +
        String(d.getMonth() + 1).padStart(2, '0') + '-' +
        String(d.getDate()).padStart(2, '0');
    }
    return null;
  }

  function updateDates(stats) {
    if (!stats) return;
    var date = formatDate(stats.generated_at);
    if (!date) return;
    document.querySelectorAll('[data-stat-date]').forEach(function(el) {
      el.textContent = date;
    });
  }

  function updateMetaTags(stats) {
    if (!stats) return;
    document.querySelectorAll('meta[data-stat-content]').forEach(meta => {
      let content = meta.getAttribute('data-stat-content');
      for (const [k, v] of Object.entries(stats)) {
        const formatted = (typeof v === 'number') ? formatNumber(v) : v;
        content = content.replace(new RegExp(`{${k}}`, 'g'), formatted);
      }
      meta.setAttribute('content', content);
    });
  }

  async function loadStats() {
    try {
      let response = await fetch(statsPath);
      if (!response.ok) {
        response = await fetch(fallbackStatsPath);
      }
      if (!response.ok) return;

      const data = await response.json();
      // Normalize data if coming from public-snapshot schema
      let stats = data;
      if (data.pipeline && data.pipeline.eas_built) {
        stats = {
          eas_compiled: data.pipeline.eas_built,
          strategy_cards: data.pipeline.strategy_cards,
          ...data
        };
      }

      // Expose for other page scripts (e.g. the strategy archive KPI
      // surfaces) so stats.json values win over locally-derived counts
      // regardless of which script resolves first.
      window.__QM_STATS = stats;

      updateElements(stats);
      updateDates(stats);
      updateMetaTags(stats);
    } catch (e) {
      console.warn('QuantMechanica: Could not load live dynamic stats', e);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', loadStats);
  } else {
    loadStats();
  }
})();
