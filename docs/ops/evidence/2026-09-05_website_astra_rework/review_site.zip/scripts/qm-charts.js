/*!
 * qm-charts.js — QuantMechanica chart engine v2 ("terminal-faithful" light charts)
 * Self-contained, no third-party library. Exposes window.QMCharts with:
 *   QMCharts.equity(canvasEl, {src, theme})       — real aggregate equity curve
 *   QMCharts.candles(canvasEl, {instrument, ...})  — calibrated synthetic OHLC
 *   QMCharts.gateStrip(el, {gates:[...]})          — 18 gate dots as DOM
 *
 * Themes: 'light' (default — TradingView-style light chart on white),
 *         'mt5'   (MetaTrader 5 "Black on White" profile: hollow bulls, black bears),
 *         'dark'  (legacy black product panel).
 * HiDPI aware, ResizeObserver-driven, honours prefers-reduced-motion.
 * Price data is SYNTHETIC (calibrated per instrument, fixed seed) — the page
 * caption must say so. Nothing here is a quote.
 */
(function () {
  'use strict';

  /* =====================================================================
   * 0. Small utilities
   * =================================================================== */

  var REDUCED_MOTION =
    typeof window.matchMedia === 'function' &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  var FONT = '"Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif';
  var MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  function clamp(x, lo, hi) { return x < lo ? lo : x > hi ? hi : x; }
  function dpr() { return Math.max(1, Math.min(window.devicePixelRatio || 1, 3)); }
  function pad2(n) { return n < 10 ? '0' + n : '' + n; }

  // FNV-1a style string/number -> uint32 seed
  function hashSeed(input) {
    var s = String(input);
    var h = 0x811c9dc5;
    for (var i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0;
    }
    return h >>> 0;
  }

  // mulberry32 — small, fast, deterministic PRNG
  function makeRng(seed) {
    var a = hashSeed(seed) >>> 0;
    return function () {
      a |= 0; a = (a + 0x6d2b79f5) | 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  // Standard normal via Box-Muller (cached spare)
  function makeGaussian(rng) {
    var spare = null;
    return function () {
      if (spare !== null) { var s = spare; spare = null; return s; }
      var u, v, r;
      do {
        u = rng() * 2 - 1;
        v = rng() * 2 - 1;
        r = u * u + v * v;
      } while (r === 0 || r >= 1);
      var f = Math.sqrt(-2 * Math.log(r) / r);
      spare = v * f;
      return u * f;
    };
  }

  // Marsaglia–Tsang Gamma(shape k, scale 1)
  function makeGamma(rng, gauss) {
    function gamma1(k) {
      if (k < 1) {
        var u = rng();
        return gamma1(1 + k) * Math.pow(u, 1 / k);
      }
      var d = k - 1 / 3;
      var c = 1 / Math.sqrt(9 * d);
      for (;;) {
        var x, vv;
        do {
          x = gauss();
          vv = 1 + c * x;
        } while (vv <= 0);
        vv = vv * vv * vv;
        var uu = rng();
        if (uu < 1 - 0.0331 * x * x * x * x) return d * vv;
        if (Math.log(uu) < 0.5 * x * x + d * (1 - vv + Math.log(vv))) return d * vv;
      }
    }
    return gamma1;
  }

  // Skewed Student-t innovation, approx unit variance.
  function makeSkewT(rng, gauss, gamma, nu, skew) {
    var tVarScale = nu > 2 ? Math.sqrt(nu / (nu - 2)) : 1;
    var skewNorm = Math.sqrt(1 + skew * skew);
    return function () {
      var z = gauss();
      var w = 2 * gamma(nu / 2);
      var t = z / Math.sqrt(w / nu);
      t /= tVarScale;
      t = (t >= 0 ? t * (1 + skew) : t * (1 - skew)) / skewNorm;
      return t;
    };
  }

  /* =====================================================================
   * 1. Theme palettes
   *    light = TradingView light chart (white ground, teal/red candles)
   *    mt5   = MetaTrader 5 "Black on White" profile
   *    dark  = legacy black product panel
   * =================================================================== */

  function palette(theme) {
    if (theme === 'mt5') {
      return {
        name: 'mt5',
        bg: '#ffffff', text: '#000000', textDim: '#3c3c3c',
        grid: '#c8c8c8', gridDash: [1, 3], axisLine: '#000000',
        up: '#000000', down: '#000000', upFill: '#ffffff', downFill: '#000000', wick: '#000000',
        volUp: 'rgba(60,140,60,0.6)', volDown: 'rgba(60,140,60,0.6)',
        tagText: '#ffffff', tagUp: '#000000', tagDown: '#000000',
        line: '#0a7d4f', area: 'rgba(10,125,79,0.08)', dd: 'rgba(200,65,45,0.10)', ddLine: '#8c8c8c',
        ema20: '#1e5fd6', ema50: '#d97706', bb: '#6b7280', bbFill: 'rgba(107,114,128,0.06)', ann: '#000000'
      };
    }
    if (theme === 'dark') {
      return {
        name: 'dark',
        bg: '#000000', text: '#d1d4dc', textDim: '#8a8d97',
        grid: 'rgba(255,255,255,0.07)', gridDash: null, axisLine: 'rgba(255,255,255,0.16)',
        up: '#26a69a', down: '#ef5350', upFill: '#26a69a', downFill: '#ef5350', wick: null,
        volUp: 'rgba(38,166,154,0.45)', volDown: 'rgba(239,83,80,0.45)',
        tagText: '#ffffff', tagUp: '#26a69a', tagDown: '#ef5350',
        line: '#34d399', area: 'rgba(255,255,255,0.08)', dd: 'rgba(239,83,80,0.14)', ddLine: 'rgba(255,255,255,0.28)',
        ema20: '#6ea8fe', ema50: '#ffb057', bb: '#7aa2ff', bbFill: 'rgba(122,162,255,0.06)', ann: '#d1d4dc'
      };
    }
    // light (default)
    return {
      name: 'light',
      bg: '#ffffff', text: '#131722', textDim: '#787b86',
      grid: '#f0f3fa', gridDash: null, axisLine: '#e0e3eb',
      up: '#26a69a', down: '#ef5350', upFill: '#26a69a', downFill: '#ef5350', wick: null,
      volUp: 'rgba(38,166,154,0.45)', volDown: 'rgba(239,83,80,0.45)',
      tagText: '#ffffff', tagUp: '#26a69a', tagDown: '#ef5350',
      line: '#0a7d4f', area: 'rgba(10,125,79,0.10)', dd: 'rgba(239,83,80,0.10)', ddLine: '#b2b5be',
      ema20: '#2962ff', ema50: '#ff6d00', bb: '#2962ff', bbFill: 'rgba(41,98,255,0.05)', ann: '#131722'
    };
  }

  /* =====================================================================
   * 2. Per-instrument calibration
   * Daily statistics fitted offline: close-to-close vol, GARCH(1,1)
   * persistence, Student-t nu, skew, jump frequency, opening-gap behaviour,
   * slow drift regime (AR(1) mean), tick size and decimals.
   * Levels are illustrative round numbers near recent market levels.
   * =================================================================== */

  var INSTRUMENTS = {
    EURUSD: {
      label: 'EUR/USD', symbol: 'EURUSD', kind: 'fx', start: 1.1608, decimals: 5, tick: 0.00001,
      vol: 0.0042, alpha: 0.06, beta: 0.91, nu: 6.5, skew: -0.02, jumpProb: 0.06, jumpScale: 1.6,
      gapProb: 0.0, gapScale: 0.0, driftPhi: 0.96, driftSigma: 0.00025, trend: 0.00002
    },
    XAUUSD: {
      label: 'XAU/USD', symbol: 'XAUUSD', kind: 'metal', start: 3418.0, decimals: 2, tick: 0.01,
      vol: 0.0105, alpha: 0.08, beta: 0.89, nu: 5.0, skew: -0.05, jumpProb: 0.08, jumpScale: 1.8,
      gapProb: 0.15, gapScale: 0.25, driftPhi: 0.96, driftSigma: 0.0006, trend: 0.00035
    },
    US100: {
      label: 'US 100', symbol: 'US100', kind: 'index', start: 23540.0, decimals: 1, tick: 0.1,
      vol: 0.0118, alpha: 0.10, beta: 0.87, nu: 4.5, skew: -0.10, jumpProb: 0.08, jumpScale: 2.0,
      gapProb: 0.9, gapScale: 0.3, driftPhi: 0.95, driftSigma: 0.0007, trend: 0.00045
    }
  };
  INSTRUMENTS.NDX = INSTRUMENTS.US100;
  INSTRUMENTS.NAS100 = INSTRUMENTS.US100;
  INSTRUMENTS.GOLD = INSTRUMENTS.XAUUSD;

  function resolveInstrument(name) {
    var key = String(name || 'EURUSD').toUpperCase().replace('/', '').replace(' ', '');
    return INSTRUMENTS[key] || INSTRUMENTS.EURUSD;
  }

  /* =====================================================================
   * 3. Time axis + synthetic OHLC generator
   * =================================================================== */

  var TF = {
    H1: { ms: 3600e3, label: '1h', perDay: 24 },
    H4: { ms: 4 * 3600e3, label: '4h', perDay: 6 },
    D1: { ms: 86400e3, label: '1D', perDay: 1 }
  };
  var ANCHOR = Date.UTC(2026, 7, 28, 20, 0, 0); // fixed illustrative anchor (Fri 28 Aug 2026 20:00 UTC)

  // FX 24x5 clock: closed Fri 21:00 UTC -> Sun 21:00 UTC
  function isFxOpen(t) {
    var d = new Date(t), wd = d.getUTCDay(), h = d.getUTCHours();
    if (wd === 6) return false;
    if (wd === 5 && h >= 21) return false;
    if (wd === 0 && h < 21) return false;
    return true;
  }

  function buildTimes(tf, bars) {
    var out = [];
    if (tf === 'D1') {
      var d = new Date(Date.UTC(2026, 7, 28));
      while (out.length < bars) {
        var wd = d.getUTCDay();
        if (wd !== 0 && wd !== 6) out.push(d.getTime());
        d.setUTCDate(d.getUTCDate() - 1);
      }
    } else {
      var step = TF[tf].ms, t = ANCHOR;
      while (out.length < bars) {
        if (isFxOpen(t)) out.push(t);
        t -= step;
      }
    }
    out.reverse();
    return out;
  }

  function normalise(arr) {
    var m = 0;
    for (var i = 0; i < arr.length; i++) m += arr[i];
    m /= arr.length;
    return arr.map(function (x) { return x / m; });
  }

  // intraday volatility / activity profile by UTC hour (Asia quiet, London
  // open, NY overlap peak, late NY fade) — normalised to mean 1
  var HOUR_VOL = normalise([0.55, 0.5, 0.5, 0.55, 0.6, 0.65, 0.85, 1.25, 1.4, 1.3, 1.15, 1.05,
    1.35, 1.55, 1.5, 1.35, 1.15, 0.95, 0.8, 0.7, 0.6, 0.55, 0.55, 0.55]);
  var HOUR_VOLUME = normalise(HOUR_VOL.map(function (x) { return Math.pow(x, 1.6); }));

  function generateSeries(inst, seed, bars, tf) {
    var rng = makeRng(seed + '|' + inst.symbol + '|' + tf + '|' + bars + '|v2');
    var gauss = makeGaussian(rng);
    var gamma = makeGamma(rng, gauss);
    var fat = makeSkewT(rng, gauss, gamma, inst.nu, inst.skew);
    var times = buildTimes(tf, bars);
    var perDay = TF[tf].perDay;
    var tfScale = 1 / Math.sqrt(perDay);          // per-bar vol relative to daily
    var baseVol = inst.vol * tfScale;
    var targetVar = baseVol * baseVol;
    var omega = targetVar * (1 - inst.alpha - inst.beta);
    var sigma2 = targetVar;
    var lastShock = 0;
    var mu = 0, phi = inst.driftPhi, muSd = inst.driftSigma * tfScale;
    var trend = inst.trend / perDay;
    var prevClose = inst.start;
    var N = 16;                                     // intra-bar sub-steps (path -> high/low)
    var out = [];
    var tk = inst.tick;
    function snap(p) { return Math.round(p / tk) * tk; }

    for (var i = 0; i < bars; i++) {
      var t = times[i];
      var dt = new Date(t), hour = dt.getUTCHours(), wd = dt.getUTCDay();
      sigma2 = omega + inst.alpha * lastShock * lastShock + inst.beta * sigma2;
      var sigma = Math.sqrt(sigma2) * (tf === 'D1' ? 1 : HOUR_VOL[hour]);
      mu = phi * mu + muSd * Math.sqrt(1 - phi * phi) * gauss();
      var drift = mu + trend;

      // opening gap: indices gap most days, metals sometimes, FX only over the weekend
      var gap = 0;
      if (tf === 'D1') {
        gap = rng() < inst.gapProb ? sigma * inst.gapScale * gauss() : sigma * 0.03 * gauss();
        if (wd === 1 && inst.kind === 'fx') gap = sigma * 0.15 * gauss();
      } else {
        var prevT = i > 0 ? times[i - 1] : t - TF[tf].ms;
        if (t - prevT > TF[tf].ms * 2) gap = inst.vol * 0.3 * gauss();
      }
      var open = prevClose * (1 + gap);

      // intra-bar random path with an occasional fat-tailed jump
      var p = open, hi = open, lo = open;
      var jumpAt = rng() < inst.jumpProb ? Math.floor(rng() * N) : -1;
      var sd = sigma / Math.sqrt(N);
      for (var k = 0; k < N; k++) {
        var r = drift / N + sd * gauss();
        if (k === jumpAt) r += sigma * inst.jumpScale * fat() * 0.6;
        p *= (1 + r);
        if (p > hi) hi = p;
        if (p < lo) lo = p;
      }
      var close = p;
      lastShock = Math.log(close / open) - drift;

      var o = snap(open), c = snap(close), h = snap(hi), l = snap(lo);
      h = Math.max(h, o, c); l = Math.min(l, o, c);

      // volume proxy: range-correlated, session/weekday profile, noise
      var rel = ((hi - lo) / open) / (1.5 * sigma || 1e-9);
      var prof = tf === 'D1' ? (wd === 1 || wd === 5 ? 0.85 : 1.0) : HOUR_VOLUME[hour];
      var v = (0.5 + 0.8 * rel) * prof * (0.75 + 0.5 * rng());

      out.push({ i: i, t: t, o: o, h: h, l: l, c: c, v: v, up: c >= o });
      prevClose = close;
    }
    // re-anchor: the LAST close sits at the instrument's reference level, so the
    // visible window always ends near a current-looking price
    var scale = inst.start / out[out.length - 1].c;
    for (var z = 0; z < out.length; z++) {
      var cz = out[z];
      cz.o = snap(cz.o * scale); cz.c = snap(cz.c * scale);
      cz.h = Math.max(snap(cz.h * scale), cz.o, cz.c); cz.l = Math.min(snap(cz.l * scale), cz.o, cz.c);
      cz.up = cz.c >= cz.o;
    }
    return { candles: out, times: times, inst: inst, tf: tf };
  }

  /* =====================================================================
   * 4. Indicators (computed from the series, not painted)
   * =================================================================== */

  function ema(values, period) {
    var out = new Array(values.length).fill(null);
    var k = 2 / (period + 1);
    var prev = null;
    for (var i = 0; i < values.length; i++) {
      if (prev === null) {
        if (i >= period - 1) {
          var s = 0;
          for (var j = i - period + 1; j <= i; j++) s += values[j];
          prev = s / period;
          out[i] = prev;
        }
      } else {
        prev = values[i] * k + prev * (1 - k);
        out[i] = prev;
      }
    }
    return out;
  }

  function bollinger(values, period, mult) {
    var up = new Array(values.length).fill(null);
    var mid = new Array(values.length).fill(null);
    var lo = new Array(values.length).fill(null);
    for (var i = period - 1; i < values.length; i++) {
      var s = 0, s2 = 0;
      for (var j = i - period + 1; j <= i; j++) { s += values[j]; s2 += values[j] * values[j]; }
      var m = s / period;
      var variance = Math.max(0, s2 / period - m * m);
      var sd = Math.sqrt(variance);
      mid[i] = m; up[i] = m + mult * sd; lo[i] = m - mult * sd;
    }
    return { up: up, mid: mid, lo: lo };
  }

  /* =====================================================================
   * 5. HiDPI canvas + ResizeObserver plumbing
   * =================================================================== */

  function fitCanvas(canvas) {
    var rect = canvas.getBoundingClientRect();
    var cssW = Math.max(1, Math.round(rect.width || canvas.clientWidth || 320));
    var cssH = Math.max(1, Math.round(rect.height || canvas.clientHeight || 200));
    var ratio = dpr();
    canvas.width = Math.round(cssW * ratio);
    canvas.height = Math.round(cssH * ratio);
    var ctx = canvas.getContext('2d');
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    return { ctx: ctx, w: cssW, h: cssH };
  }

  function attachResize(canvas, drawFn) {
    var scheduled = false;
    function schedule() {
      if (scheduled) return;
      scheduled = true;
      window.requestAnimationFrame(function () { scheduled = false; drawFn(); });
    }
    var ro = null;
    if (typeof ResizeObserver !== 'undefined') {
      ro = new ResizeObserver(schedule);
      ro.observe(canvas);
    } else {
      window.addEventListener('resize', schedule);
    }
    return function destroy() {
      if (ro) ro.disconnect();
      else window.removeEventListener('resize', schedule);
    };
  }

  function niceStep(range, target) {
    var raw = range / Math.max(1, target);
    var mag = Math.pow(10, Math.floor(Math.log10(raw)));
    var norm = raw / mag;
    var step = norm >= 5 ? 5 : norm >= 2.5 ? 2.5 : norm >= 2 ? 2 : 1;
    return step * mag;
  }

  function fmtPrice(p, decimals) { return p.toFixed(decimals); }

  function gridLine(ctx, pal, x0, y0, x1, y1) {
    ctx.strokeStyle = pal.grid; ctx.lineWidth = 1;
    if (pal.gridDash) ctx.setLineDash(pal.gridDash);
    ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
    if (pal.gridDash) ctx.setLineDash([]);
  }

  function hairline(ctx, color, x0, y0, x1, y1) {
    ctx.strokeStyle = color; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
  }

  /* =====================================================================
   * 6. Equity renderer — real aggregate curve
   * =================================================================== */

  function equity(canvas, opts) {
    opts = opts || {};
    var theme = opts.theme || 'light';
    var src = opts.src || '/public-data/hero-equity.json';
    var pal = palette(theme);
    var data = null;
    var destroyResize = null;

    function draw() {
      if (!data) return;
      var fit = fitCanvas(canvas);
      var ctx = fit.ctx, W = fit.w, H = fit.h;
      ctx.fillStyle = pal.bg; ctx.fillRect(0, 0, W, H);

      var series = data.series || [];
      if (series.length < 2) return;

      ctx.font = '11px ' + FONT;
      var ys = series.map(function (p) { return p[1]; });
      var xs = series.map(function (p) { return Date.parse(p[0]); });
      var yMin = Math.min.apply(null, ys), yMax = Math.max.apply(null, ys);
      var yPad = (yMax - yMin) * 0.06 || 1;
      yMin -= yPad; yMax += yPad;

      var axisW = Math.ceil(ctx.measureText(Math.round(yMax).toString()).width) + 16;
      var padL = 8, padR = Math.max(44, axisW), padT = 12, padB = 22;
      var plotW = W - padL - padR;
      var plotH = H - padT - padB;
      var x0 = xs[0], x1 = xs[xs.length - 1];

      function X(t) { return padL + (t - x0) / (x1 - x0) * plotW; }
      function Y(v) { return padT + (1 - (v - yMin) / (yMax - yMin)) * plotH; }

      // horizontal grid + right-axis index labels
      ctx.textBaseline = 'middle'; ctx.textAlign = 'left'; ctx.fillStyle = pal.textDim;
      var step = niceStep(yMax - yMin, Math.max(3, Math.floor(plotH / 44)));
      for (var gy = Math.ceil(yMin / step) * step; gy <= yMax; gy += step) {
        var yy = Math.round(Y(gy)) + 0.5;
        gridLine(ctx, pal, padL, yy, padL + plotW, yy);
        ctx.fillText(Math.round(gy).toString(), padL + plotW + 8, yy);
      }

      // year ticks: gridline every year, labels decimated to the width
      var yStart = new Date(x0).getUTCFullYear(), yEnd = new Date(x1).getUTCFullYear();
      var yearTicks = [];
      for (var yr = yStart; yr <= yEnd; yr++) {
        var t = Date.UTC(yr, 0, 1);
        if (t < x0 || t > x1) continue;
        yearTicks.push({ yr: yr, xx: Math.round(X(t)) + 0.5 });
      }
      for (var g = 0; g < yearTicks.length; g++) gridLine(ctx, pal, yearTicks[g].xx, padT, yearTicks[g].xx, padT + plotH);
      ctx.textAlign = 'center'; ctx.textBaseline = 'top'; ctx.fillStyle = pal.textDim;
      var minLabelGap = ctx.measureText('2020').width + 10;
      var lastLabelX = -Infinity;
      for (var ln = 0; ln < yearTicks.length; ln++) {
        if (yearTicks[ln].xx - lastLabelX < minLabelGap) continue;
        ctx.fillText(String(yearTicks[ln].yr), yearTicks[ln].xx, padT + plotH + 7);
        lastLabelX = yearTicks[ln].xx;
      }

      // running-high + drawdown shading
      var run = ys.slice();
      for (var i = 1; i < run.length; i++) run[i] = Math.max(run[i - 1], ys[i]);
      ctx.beginPath();
      ctx.moveTo(X(xs[0]), Y(run[0]));
      for (var a = 1; a < xs.length; a++) ctx.lineTo(X(xs[a]), Y(run[a]));
      for (var b = xs.length - 1; b >= 0; b--) ctx.lineTo(X(xs[b]), Y(ys[b]));
      ctx.closePath(); ctx.fillStyle = pal.dd; ctx.fill();
      ctx.beginPath();
      ctx.moveTo(X(xs[0]), Y(run[0]));
      for (var r = 1; r < xs.length; r++) ctx.lineTo(X(xs[r]), Y(run[r]));
      ctx.strokeStyle = pal.ddLine; ctx.lineWidth = 1; ctx.setLineDash([2, 3]); ctx.stroke(); ctx.setLineDash([]);

      // area + line (thin, jagged, unsmoothed)
      ctx.beginPath();
      ctx.moveTo(X(xs[0]), Y(ys[0]));
      for (var c = 1; c < xs.length; c++) ctx.lineTo(X(xs[c]), Y(ys[c]));
      ctx.lineTo(X(xs[xs.length - 1]), padT + plotH);
      ctx.lineTo(X(xs[0]), padT + plotH);
      ctx.closePath(); ctx.fillStyle = pal.area; ctx.fill();
      ctx.beginPath();
      ctx.moveTo(X(xs[0]), Y(ys[0]));
      for (var d2 = 1; d2 < xs.length; d2++) ctx.lineTo(X(xs[d2]), Y(ys[d2]));
      ctx.strokeStyle = pal.line; ctx.lineWidth = 1.5; ctx.lineJoin = 'round'; ctx.stroke();

      // axis borders + last-value tag
      hairline(ctx, pal.axisLine, padL + plotW + 0.5, padT, padL + plotW + 0.5, padT + plotH);
      hairline(ctx, pal.axisLine, padL, Math.round(padT + plotH) + 0.5, W, Math.round(padT + plotH) + 0.5);
      var lastY = Math.round(Y(ys[ys.length - 1]));
      ctx.setLineDash([3, 3]); hairline(ctx, pal.line, padL, lastY + 0.5, padL + plotW, lastY + 0.5); ctx.setLineDash([]);
      ctx.fillStyle = pal.line;
      ctx.fillRect(padL + plotW + 1, lastY - 9, padR - 2, 18);
      ctx.fillStyle = '#ffffff'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(Math.round(ys[ys.length - 1]).toString(), padL + plotW + padR / 2, lastY);
    }

    fetch(src, { cache: 'no-cache' })
      .then(function (r) { if (!r.ok) throw new Error('http ' + r.status); return r.json(); })
      .then(function (j) {
        data = j;
        draw();
        destroyResize = attachResize(canvas, draw);
      })
      .catch(function (e) {
        var fit = fitCanvas(canvas);
        var ctx = fit.ctx;
        ctx.fillStyle = pal.bg; ctx.fillRect(0, 0, fit.w, fit.h);
        ctx.fillStyle = pal.textDim;
        ctx.font = '13px ' + FONT;
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('equity data unavailable', fit.w / 2, fit.h / 2);
        if (window.console) console.warn('QMCharts.equity:', e && e.message);
      });

    return {
      redraw: draw,
      destroy: function () { if (destroyResize) destroyResize(); }
    };
  }

  /* =====================================================================
   * 7. Candles renderer — calibrated synthetic OHLC, terminal layout
   *    (legend, right price scale with last-price tag, time scale, volume
   *    overlay in the lower part of the pane, session boxes, overlays)
   * =================================================================== */

  function candles(canvas, opts) {
    opts = opts || {};
    var theme = opts.theme || 'light';
    var pal = palette(theme);
    var inst = resolveInstrument(opts.instrument);
    var tf = TF[opts.tf] ? opts.tf : 'D1';
    var bars = clamp(opts.bars || 64, 20, 400);
    var seed = opts.seed != null ? opts.seed : 'qm';
    var overlays = opts.overlays || [];
    var annotations = opts.annotations || [];
    var sessions = opts.sessions || [];
    var showLegend = opts.legend !== false;
    var showVolume = opts.volume !== false;
    var wantLive = !!opts.live && !REDUCED_MOTION;

    // generate a warm-up prefix so overlays are defined from the first visible bar
    var WARM = 60;
    var gen = generateSeries(inst, seed, bars + WARM, tf);
    var series = gen.candles.slice(WARM).map(function (k, idx) { k.i = idx; return k; });
    var times = gen.times.slice(WARM);
    var closesAll = gen.candles.map(function (k) { return k.c; });

    function sliceInd(arr) { return arr ? arr.slice(WARM) : null; }
    var indEma20 = overlays.indexOf('ema20') >= 0 ? sliceInd(ema(closesAll, 20)) : null;
    var indEma50 = overlays.indexOf('ema50') >= 0 ? sliceInd(ema(closesAll, 50)) : null;
    var indBB = null;
    if (overlays.indexOf('bb') >= 0) {
      var bbAll = bollinger(closesAll, 20, 2);
      indBB = { up: sliceInd(bbAll.up), mid: sliceInd(bbAll.mid), lo: sliceInd(bbAll.lo) };
    }

    // resolve annotations: markers may sit on the extreme of a range
    var resolved = annotations.map(function (an) {
      var a = {};
      for (var key in an) if (Object.prototype.hasOwnProperty.call(an, key)) a[key] = an[key];
      if (a.type === 'marker' && (a.at === 'max' || a.at === 'min')) {
        var rg = a.range || [0, bars - 1];
        var lo = clamp(Math.min(rg[0], rg[1]), 0, bars - 1), hi = clamp(Math.max(rg[0], rg[1]), 0, bars - 1);
        var best = lo;
        for (var q = lo; q <= hi; q++) {
          if (a.at === 'max' ? series[q].h > series[best].h : series[q].l < series[best].l) best = q;
        }
        a.high = a.at === 'max';
        a.at = best;
      }
      return a;
    });

    // session boxes (intraday only): contiguous runs of bars inside [from,to) UTC on one day
    var sessionBands = [];
    if (tf !== 'D1') {
      sessions.forEach(function (s, sIdx) {
        var runStart = -1, runDay = -1;
        for (var i = 0; i <= bars; i++) {
          var inside = false, day = -1;
          if (i < bars) {
            var d = new Date(times[i]);
            day = d.getUTCDate();
            var h = d.getUTCHours();
            inside = h >= s.from && h < s.to;
          }
          if (runStart >= 0 && (!inside || day !== runDay)) {
            sessionBands.push({ type: 'band', from: runStart, to: i - 1, color: s.color, label: s.label, short: s.short, edge: s.edge, labelColor: s.labelColor, labelRow: sIdx });
            runStart = -1;
          }
          if (inside && runStart < 0) { runStart = i; runDay = day; }
        }
      });
    }

    var destroyResize = null;
    var rafId = null;
    var lastTick = 0;
    var liveRng = makeRng(seed + '|live|' + inst.symbol);
    var liveGauss = makeGaussian(liveRng);
    var baseLast = { o: series[bars - 1].o, h: series[bars - 1].h, l: series[bars - 1].l, c: series[bars - 1].c };
    var liveState = null;

    function timeTicks() {
      var out = [];
      for (var i = 0; i < bars; i++) {
        var d = new Date(times[i]);
        var prev = i > 0 ? new Date(times[i - 1]) : null;
        if (tf === 'D1') {
          if (!prev || d.getUTCMonth() !== prev.getUTCMonth()) {
            out.push({ i: i, major: true, label: d.getUTCMonth() === 0 || !prev ? MONTHS[d.getUTCMonth()] + " '" + String(d.getUTCFullYear()).slice(2) : MONTHS[d.getUTCMonth()] });
          } else if (d.getUTCDay() === 1) {
            out.push({ i: i, major: false, label: String(d.getUTCDate()) });
          }
        } else {
          if (!prev || d.getUTCDate() !== prev.getUTCDate()) {
            out.push({ i: i, major: true, label: (!prev ? MONTHS[d.getUTCMonth()] + ' ' : '') + d.getUTCDate() });
          } else if (d.getUTCHours() % (tf === 'H1' ? 6 : 12) === 0) {
            out.push({ i: i, major: false, label: pad2(d.getUTCHours()) + ':00' });
          }
        }
      }
      return out;
    }

    function draw() {
      var fit = fitCanvas(canvas);
      var ctx = fit.ctx, W = fit.w, H = fit.h;
      ctx.fillStyle = pal.bg; ctx.fillRect(0, 0, W, H);
      ctx.font = '11px ' + FONT;

      // price extent (highs/lows, BB if present, live candle)
      var pMin = Infinity, pMax = -Infinity;
      for (var i = 0; i < bars; i++) {
        var lo0 = series[i].l, hi0 = series[i].h;
        if (i === bars - 1 && liveState) { lo0 = Math.min(lo0, liveState.l); hi0 = Math.max(hi0, liveState.h); }
        if (lo0 < pMin) pMin = lo0;
        if (hi0 > pMax) pMax = hi0;
      }
      if (indBB) {
        for (var b = 0; b < bars; b++) {
          if (indBB.up[b] != null && indBB.up[b] > pMax) pMax = indBB.up[b];
          if (indBB.lo[b] != null && indBB.lo[b] < pMin) pMin = indBB.lo[b];
        }
      }
      var pPad = (pMax - pMin) * 0.04 || inst.tick;
      pMin -= pPad; pMax += pPad;

      // layout
      var axisW = Math.ceil(Math.max(ctx.measureText(fmtPrice(pMax, inst.decimals)).width, ctx.measureText(fmtPrice(pMin, inst.decimals)).width)) + 16;
      var legendRows = showLegend ? 1 : 0;
      var padL = 4, padR = Math.max(48, axisW), padB = 20;
      var plotW = W - padL - padR;
      var plotRight = padL + plotW;
      var slot = plotW / bars;
      var gapPx = Math.max(1, Math.round(slot * 0.28));
      var bodyW = Math.max(1, Math.floor(slot) - gapPx);
      if (bodyW > 1 && bodyW % 2 === 0) bodyW -= 1;   // odd width centres on the 1px wick

      // legend text (measured first: it decides the top padding)
      var last = series[bars - 1];
      var lo_ = last.o, lh = last.h, ll = last.l, lc = last.c;
      if (liveState) { lo_ = liveState.o; lh = liveState.h; ll = liveState.l; lc = liveState.c; }
      var prevC = bars > 1 ? series[bars - 2].c : lo_;
      var chg = lc - prevC, chgPct = prevC ? chg / prevC * 100 : 0;
      var lastUp = lc >= lo_;
      var lastCol = lastUp ? pal.up : pal.down;
      var legendTitle = inst.label + ' · ' + TF[tf].label;
      var ohlc = [['O', fmtPrice(lo_, inst.decimals)], ['H', fmtPrice(lh, inst.decimals)], ['L', fmtPrice(ll, inst.decimals)], ['C', fmtPrice(lc, inst.decimals)]];
      var chgText = (chg >= 0 ? '+' : '−') + fmtPrice(Math.abs(chg), inst.decimals) + ' (' + (chgPct >= 0 ? '+' : '−') + Math.abs(chgPct).toFixed(2) + '%)';
      var ohlcW = 0;
      ctx.font = '11px ' + FONT;
      ohlc.forEach(function (p) { ohlcW += ctx.measureText(p[0]).width + 2 + ctx.measureText(p[1]).width + 8; });
      var chgW = ctx.measureText(chgText).width;
      ctx.font = '500 12px ' + FONT;
      var titleW = ctx.measureText(legendTitle).width;
      var wrapOhlc = showLegend && (titleW + 12 + ohlcW + chgW > plotW - 8);
      var showChg = !wrapOhlc || ohlcW + chgW <= plotW - 12;   // narrow panes drop the change figure
      if (wrapOhlc && ohlcW > plotW - 12) ohlc = [ohlc[3]];       // very narrow: close only
      if (wrapOhlc) legendRows = 2;
      var ovLegend = [];
      if (indEma20) ovLegend.push({ label: 'EMA 20', color: pal.ema20, value: indEma20[bars - 1] });
      if (indEma50) ovLegend.push({ label: 'EMA 50', color: pal.ema50, value: indEma50[bars - 1] });
      if (indBB) ovLegend.push({ label: 'BB 20 · 2', color: pal.bb, value: null });
      if (showLegend && ovLegend.length) legendRows += 1;
      var padT = 6 + legendRows * 15;
      var paneTop = padT, paneBottom = H - padB, paneH = paneBottom - paneTop;
      var priceTop = paneTop + paneH * 0.05;
      var priceH = paneH * (showVolume ? 0.72 : 0.9);
      var volTop = paneBottom - paneH * 0.2;

      function X(idx) { return padL + (idx + 0.5) * slot; }
      function Y(p) { return priceTop + (1 - (p - pMin) / (pMax - pMin)) * priceH; }
      var vMax = 0;
      for (var vv = 0; vv < bars; vv++) if (series[vv].v > vMax) vMax = series[vv].v;
      function VY(v) { return paneBottom - (v / (vMax || 1)) * (paneBottom - volTop); }

      // session boxes + bands (behind everything)
      sessionBands.concat(resolved).forEach(function (an) {
        if (an.type !== 'band') return;
        var xa = Math.round(X(clamp(an.from, 0, bars - 1)) - slot / 2);
        var xb = Math.round(X(clamp(an.to, 0, bars - 1)) + slot / 2);
        ctx.fillStyle = an.color || 'rgba(41,98,255,0.06)';
        ctx.fillRect(xa, paneTop, xb - xa, paneH);
        if (an.edge) { hairline(ctx, an.edge, xa + 0.5, paneTop, xa + 0.5, paneBottom); hairline(ctx, an.edge, xb - 0.5, paneTop, xb - 0.5, paneBottom); }
        if (an.label) {
          ctx.font = '10px ' + FONT;
          var text = an.label;
          if (xb - xa < ctx.measureText(text).width + 4 && an.short) text = an.short;
          if (xb - xa >= ctx.measureText(text).width + 4) {
            ctx.fillStyle = an.labelColor || pal.textDim; ctx.textAlign = 'left'; ctx.textBaseline = 'top';
            ctx.fillText(text, xa + 3, paneTop + 3 + (an.labelRow || 0) * 12);
          }
        }
      });

      // price grid + right-scale labels (grid spans the whole pane, like a terminal)
      ctx.font = '11px ' + FONT;
      var priceRange = pMax - pMin;
      var step = niceStep(priceRange * (paneH / priceH), Math.max(3, Math.floor(paneH / 40)));
      ctx.fillStyle = pal.textDim; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      var pTopVisible = pMin + (priceTop + priceH - paneTop) / priceH * priceRange;
      var pBottomVisible = pMin - (paneBottom - priceTop - priceH) / priceH * priceRange;
      var tagY = Math.round(Y(lc));
      for (var gp = Math.ceil(pBottomVisible / step) * step; gp <= pTopVisible; gp += step) {
        var gy = Math.round(Y(gp)) + 0.5;
        if (gy < paneTop + 8 || gy > paneBottom - 6) continue;
        gridLine(ctx, pal, padL, gy, plotRight, gy);
        if (Math.abs(gy - tagY) > 12) ctx.fillText(fmtPrice(gp, inst.decimals), plotRight + 8, gy);
      }

      // time grid + labels (majors first, then minors that fit)
      var ticks = timeTicks();
      ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      var placed = [];
      function fits(x, w) {
        for (var q = 0; q < placed.length; q++) if (Math.abs(placed[q].x - x) < (placed[q].w + w) / 2 + 10) return false;
        return x - w / 2 >= padL && x + w / 2 <= plotRight;
      }
      [true, false].forEach(function (major) {
        ticks.forEach(function (tk) {
          if (tk.major !== major) return;
          var x = Math.round(X(tk.i)) + 0.5;
          var w = ctx.measureText(tk.label).width;
          if (!fits(x, w)) return;
          placed.push({ x: x, w: w, label: tk.label, major: major });
        });
      });
      placed.forEach(function (p) {
        gridLine(ctx, pal, p.x, paneTop, p.x, paneBottom);
        ctx.fillStyle = p.major ? pal.text : pal.textDim;
        ctx.fillText(p.label, p.x, paneBottom + 6);
      });

      // Bollinger fill + bands
      if (indBB) {
        ctx.beginPath();
        var started = false;
        for (var u = 0; u < bars; u++) {
          if (indBB.up[u] == null) continue;
          if (!started) { ctx.moveTo(X(u), Y(indBB.up[u])); started = true; } else ctx.lineTo(X(u), Y(indBB.up[u]));
        }
        for (var lo2 = bars - 1; lo2 >= 0; lo2--) {
          if (indBB.lo[lo2] == null) continue;
          ctx.lineTo(X(lo2), Y(indBB.lo[lo2]));
        }
        ctx.closePath(); ctx.fillStyle = pal.bbFill; ctx.fill();
        drawPolyline(ctx, indBB.up, X, Y, pal.bb, 1);
        drawPolyline(ctx, indBB.lo, X, Y, pal.bb, 1);
        drawPolyline(ctx, indBB.mid, X, Y, pal.ema50, 1);
      }

      // volume (lower part of the pane, behind the candles)
      if (showVolume) {
        for (var m = 0; m < bars; m++) {
          var cm = series[m];
          ctx.fillStyle = cm.up ? pal.volUp : pal.volDown;
          var vy = Math.round(VY(cm.v));
          var vx = Math.round(X(m) - bodyW / 2);
          ctx.fillRect(vx, vy, bodyW, paneBottom - vy);
        }
      }

      // candles
      for (var k = 0; k < bars; k++) {
        var cd = series[k];
        var o = cd.o, h = cd.h, l = cd.l, c = cd.c;
        if (k === bars - 1 && liveState) { o = liveState.o; h = liveState.h; l = liveState.l; c = liveState.c; }
        var up = c >= o;
        var col = up ? pal.up : pal.down;
        var fill = up ? pal.upFill : pal.downFill;
        var cx = Math.round(X(k) - 0.5) + 0.5;
        var yO = Y(o), yC = Y(c);
        var top = Math.round(Math.min(yO, yC));
        var bot = Math.round(Math.max(yO, yC));
        // wick
        hairline(ctx, pal.wick || col, cx, Math.round(Y(h)) + 0.5, cx, Math.round(Y(l)) + 0.5);
        // body (1px border + fill; a doji is a 1px line)
        var bx = Math.round(cx - 0.5 - (bodyW - 1) / 2);
        if (bot - top < 1) {
          ctx.fillStyle = col; ctx.fillRect(bx, top, bodyW, 1);
        } else if (bodyW <= 2) {
          ctx.fillStyle = col; ctx.fillRect(bx, top, bodyW, bot - top);
        } else {
          ctx.fillStyle = fill; ctx.fillRect(bx, top, bodyW, bot - top);
          ctx.strokeStyle = col; ctx.lineWidth = 1;
          ctx.strokeRect(bx + 0.5, top + 0.5, bodyW - 1, bot - top - 1);
        }
      }

      // overlays on top
      if (indEma20) drawPolyline(ctx, indEma20, X, Y, pal.ema20, 1.5);
      if (indEma50) drawPolyline(ctx, indEma50, X, Y, pal.ema50, 1.5);

      // last price: dashed line + scale tag
      var ly = Math.round(Y(lc)) + 0.5;
      ctx.setLineDash([3, 3]); hairline(ctx, lastCol, padL, ly, plotRight, ly); ctx.setLineDash([]);
      ctx.fillStyle = lastUp ? pal.tagUp : pal.tagDown;
      ctx.fillRect(plotRight + 1, Math.round(ly) - 9, padR - 2, 18);
      ctx.fillStyle = pal.tagText; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = '11px ' + FONT;
      ctx.fillText(fmtPrice(lc, inst.decimals), plotRight + padR / 2, Math.round(ly));

      // markers + hlines
      resolved.forEach(function (an) {
        if (an.type === 'marker') {
          var idx = clamp(an.at, 0, bars - 1);
          var price = an.price != null ? an.price : (an.high ? series[idx].h : series[idx].l);
          var mx = X(idx), my = Y(price);
          var dir = an.high ? -1 : 1;
          var mc = an.color || pal.ann;
          ctx.fillStyle = mc;
          ctx.beginPath();
          ctx.moveTo(mx, my + dir * 3);
          ctx.lineTo(mx - 4, my + dir * 9);
          ctx.lineTo(mx + 4, my + dir * 9);
          ctx.closePath(); ctx.fill();
          if (an.label) {
            ctx.font = '500 10px ' + FONT;
            ctx.textAlign = 'center'; ctx.textBaseline = an.high ? 'bottom' : 'top';
            ctx.fillText(an.label, mx, my + dir * 11);
          }
        } else if (an.type === 'hline') {
          var hy = Math.round(Y(an.price)) + 0.5;
          ctx.setLineDash([4, 3]); hairline(ctx, an.color || pal.ann, padL, hy, plotRight, hy); ctx.setLineDash([]);
          if (an.label) {
            ctx.font = '10px ' + FONT;
            ctx.fillStyle = an.color || pal.ann; ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
            ctx.fillText(an.label, padL + 4, hy - 2);
          }
        }
      });

      // scale borders (drawn last so nothing paints over them)
      hairline(ctx, pal.axisLine, plotRight + 0.5, 0, plotRight + 0.5, paneBottom);
      hairline(ctx, pal.axisLine, padL, Math.round(paneBottom) + 0.5, W, Math.round(paneBottom) + 0.5);

      // legend (top-left, terminal style)
      if (showLegend) {
        var lx = padL + 6, lyy = 6;
        ctx.save();
        ctx.beginPath(); ctx.rect(0, 0, plotRight - 2, padT); ctx.clip();
        ctx.textAlign = 'left'; ctx.textBaseline = 'top';
        ctx.font = '500 12px ' + FONT; ctx.fillStyle = pal.text;
        ctx.fillText(legendTitle, lx, lyy);
        var ox = wrapOhlc ? lx : lx + titleW + 12;
        var oy = wrapOhlc ? lyy + 15 : lyy + 1;
        ctx.font = '11px ' + FONT;
        ohlc.forEach(function (p) {
          ctx.fillStyle = pal.textDim; ctx.fillText(p[0], ox, oy); ox += ctx.measureText(p[0]).width + 2;
          ctx.fillStyle = lastCol; ctx.fillText(p[1], ox, oy); ox += ctx.measureText(p[1]).width + 8;
        });
        if (showChg) { ctx.fillStyle = lastCol; ctx.fillText(chgText, ox, oy); }
        if (ovLegend.length) {
          var ry = lyy + (wrapOhlc ? 30 : 15), rx = lx;
          ovLegend.forEach(function (ov) {
            ctx.fillStyle = ov.color;
            ctx.fillRect(rx, ry + 5, 8, 2);
            rx += 12;
            ctx.fillStyle = pal.textDim; ctx.fillText(ov.label, rx, ry); rx += ctx.measureText(ov.label).width + 4;
            if (ov.value != null) { ctx.fillStyle = ov.color; var vt = fmtPrice(ov.value, inst.decimals); ctx.fillText(vt, rx, ry); rx += ctx.measureText(vt).width; }
            rx += 12;
          });
        }
        ctx.restore();
      }
    }

    function tick(ts) {
      if (!wantLive) return;
      if (ts - lastTick > 380) {
        lastTick = ts;
        if (!liveState) liveState = { o: baseLast.o, h: baseLast.h, l: baseLast.l, c: baseLast.c };
        var jitter = inst.start * inst.vol / Math.sqrt(TF[tf].perDay) * 0.12 * liveGauss();
        liveState.c = Math.round((liveState.c + jitter) / inst.tick) * inst.tick;
        liveState.h = Math.max(liveState.h, liveState.c);
        liveState.l = Math.min(liveState.l, liveState.c);
        draw();
      }
      rafId = window.requestAnimationFrame(tick);
    }

    draw();
    destroyResize = attachResize(canvas, draw);
    if (wantLive) rafId = window.requestAnimationFrame(tick);

    return {
      redraw: draw,
      series: series,
      times: times,
      destroy: function () {
        if (destroyResize) destroyResize();
        if (rafId) window.cancelAnimationFrame(rafId);
      }
    };
  }

  function drawPolyline(ctx, arr, X, Y, color, width) {
    ctx.beginPath();
    var started = false;
    for (var i = 0; i < arr.length; i++) {
      if (arr[i] == null) continue;
      var x = X(i), y = Y(arr[i]);
      if (!started) { ctx.moveTo(x, y); started = true; } else ctx.lineTo(x, y);
    }
    ctx.strokeStyle = color; ctx.lineWidth = width; ctx.lineJoin = 'round';
    ctx.stroke();
  }

  /* =====================================================================
   * 8. Gate strip — 18 dots as DOM (no canvas)
   * =================================================================== */

  var STYLE_INJECTED = false;
  function injectStyle() {
    if (STYLE_INJECTED) return;
    STYLE_INJECTED = true;
    var css =
      '.qm-gatestrip{display:flex;flex-wrap:wrap;align-items:flex-start;gap:14px 10px;' +
      'font-family:var(--font-sans,-apple-system,"Segoe UI",sans-serif)}' +
      '.qm-gate{display:flex;flex-direction:column;align-items:center;gap:6px;position:relative}' +
      '.qm-gate__dot{width:12px;height:12px;border-radius:50%;background:var(--c-text-3,#86868b);' +
      'box-shadow:0 0 0 1px rgba(0,0,0,.06) inset}' +
      '.qm-gate__id{font-size:10px;letter-spacing:.02em;color:var(--c-text-3,#86868b);' +
      'font-variant-numeric:tabular-nums}' +
      '.qm-gate--pass .qm-gate__dot{background:var(--c-pass,#2f9e5f)}' +
      '.qm-gate--pass .qm-gate__id{color:var(--c-text-2,#6e6e73)}' +
      '.qm-gate--fail .qm-gate__dot{background:var(--c-fail,#c8412d)}' +
      '.qm-gate--pending .qm-gate__dot{background:transparent;' +
      'box-shadow:0 0 0 1.5px var(--c-text-3,#86868b) inset}' +
      '.qm-gatestrip--on-dark .qm-gate__id{color:rgba(255,255,255,.55)}' +
      '.qm-gatestrip--on-dark .qm-gate--pass .qm-gate__dot{background:#34d399}' +
      '.qm-gatestrip--on-dark .qm-gate--fail .qm-gate__dot{background:#f87171}' +
      '.qm-gatestrip--on-dark .qm-gate--pending .qm-gate__dot{background:transparent;' +
      'box-shadow:0 0 0 1.5px rgba(255,255,255,.4) inset}';
    var el = document.createElement('style');
    el.id = 'qm-charts-css';
    el.textContent = css;
    document.head.appendChild(el);
  }

  function defaultGates() {
    var out = [];
    for (var i = 0; i < 18; i++) out.push({ id: 'Q' + pad2(i), state: 'pending' });
    return out;
  }

  function gateStrip(el, opts) {
    injectStyle();
    opts = opts || {};
    var gates = opts.gates && opts.gates.length ? opts.gates : defaultGates();
    var onDark = opts.theme === 'dark';

    el.classList.add('qm-gatestrip');
    if (onDark) el.classList.add('qm-gatestrip--on-dark');
    el.setAttribute('role', 'img');
    el.setAttribute('aria-label', 'Gate journey Q00 to Q17');
    el.innerHTML = '';

    gates.forEach(function (g) {
      var state = (g.state || 'pending').toLowerCase();
      if (['pass', 'fail', 'pending'].indexOf(state) < 0) state = 'pending';
      var cell = document.createElement('div');
      cell.className = 'qm-gate qm-gate--' + state;
      cell.title = g.id + ' — ' + state;
      var dot = document.createElement('span');
      dot.className = 'qm-gate__dot';
      dot.setAttribute('aria-hidden', 'true');
      var idl = document.createElement('span');
      idl.className = 'qm-gate__id';
      idl.textContent = g.id;
      cell.appendChild(dot);
      cell.appendChild(idl);
      el.appendChild(cell);
    });

    return { el: el, gates: gates };
  }

  /* =====================================================================
   * 9. Export
   * =================================================================== */

  window.QMCharts = {
    version: '2.0.0',
    equity: equity,
    candles: candles,
    gateStrip: gateStrip,
    _instruments: Object.keys(INSTRUMENTS),
    _themes: ['light', 'mt5', 'dark']
  };
})();
